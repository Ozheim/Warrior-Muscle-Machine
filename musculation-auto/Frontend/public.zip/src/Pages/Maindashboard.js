const MainDashboard = () => {
  return <div>it's working bro !</div>;
};

export default MainDashboard;
