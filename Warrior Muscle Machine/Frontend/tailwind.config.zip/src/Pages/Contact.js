const contact = () => {
  return <div>Bientot ... </div>;
};

export default contact;
